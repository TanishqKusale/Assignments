package customException;

public class InvalidInput extends Exception {
	public InvalidInput(String err) {
		super(err);
	}
}
