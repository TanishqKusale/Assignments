package customException;

public class InvalidDate extends Exception{
	public InvalidDate(String err) {
		super(err);
	}
}
