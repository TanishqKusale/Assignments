package com.core;

public enum TrainType {
	EXPRESS,PASSENGER,SUPERFAST,LOCAL;
}
