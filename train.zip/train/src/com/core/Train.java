package com.core;

import java.time.LocalDate;

public class Train {
	private String train_no;
	private String train_name;
	private String departure_time;
	private String arrival_time;
	private String source;
	private TrainType type;
	private LocalDate train_add_date;
	private String destination;
	private int no_of_bogies;
	public Train(String train_no, String train_name, String departure_time, String arrival_time, String source,
			TrainType type, LocalDate train_add_date, String destination, int no_of_bogies) {
		super();
		this.train_no = train_no;
		this.train_name = train_name;
		this.departure_time = departure_time;
		this.arrival_time = arrival_time;
		this.source = source;
		this.type = type;
		this.train_add_date = train_add_date;
		this.destination = destination;
		this.no_of_bogies = no_of_bogies;
	}
	@Override
	public String toString() {
		return "Train [train_no=" + train_no + ", train_name=" + train_name + ", departure_time=" + departure_time
				+ ", arrival_time=" + arrival_time + ", source=" + source + ", train_add_date=" + train_add_date
				+ ", destination=" + destination + ", no_of_bogies=" + no_of_bogies + "]";
	}
	public String getTrain_no() {
		return train_no;
	}
	public void setTrain_no(String train_no) {
		this.train_no = train_no;
	}
	public String getTrain_name() {
		return train_name;
	}
	public void setTrain_name(String train_name) {
		this.train_name = train_name;
	}
	public String getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(String departure_time) {
		this.departure_time = departure_time;
	}
	public String getArrival_time() {
		return arrival_time;
	}
	public void setArrival_time(String arrival_time) {
		this.arrival_time = arrival_time;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public TrainType getType() {
		return type;
	}
	public void setType(TrainType type) {
		this.type = type;
	}
	public LocalDate getTrain_add_date() {
		return train_add_date;
	}
	public void setTrain_add_date(LocalDate train_add_date) {
		this.train_add_date = train_add_date;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public int getNo_of_bogies() {
		return no_of_bogies;
	}
	public void setNo_of_bogies(int no_of_bogies) {
		this.no_of_bogies = no_of_bogies;
	}
	
	
	
}
