package validation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.Map;

import com.core.Train;
import com.core.*;

import customException.InvalidDate;
import customException.InvalidInput;

public class Validation {
	public static void writeData(Map<String, Train>map)throws FileNotFoundException,IOException{
	try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("Data.ser"))){
		oos.writeObject(map);
		}
	}
	
	public static Map<String, Train>readData()throws FileNotFoundException,IOException,ClassNotFoundException{
		try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("Data.ser"))){
			return(Map<String,Train>)ois.readObject();
		}
	}
	
	public static void checkTrainNumber(String no)throws InvalidInput{
		if(no.length()>6) {
			throw new InvalidInput("no is not correct");
		}
	}
	
	public static LocalDate checkTrainDate(String trainDate)throws InvalidDate{
		LocalDate date=LocalDate.parse(trainDate);
		int iRet=date.compareTo(LocalDate.now());
		
		if(iRet==-1) {
			throw new InvalidDate("train date is not valid");
		}
		return date;
	}
	
	public static TrainType checTrainType(String type) {
		TrainType train=TrainType.valueOf(type);
		return train;
	}
	
	public static Train addTrain(String trainNo, String train_name, String departure_time, String arrival_time,
			String source, String trainType, String train_added_date, String destination, int no_of_bogies)
			throws InvalidInput,InvalidDate{
		checkTrainNumber(trainNo);
		LocalDate validDate=checkTrainDate(train_added_date);
		TrainType validType=checTrainType(trainType);
		return new Train(trainNo, train_name, departure_time, arrival_time, source, validType, validDate, destination,
				no_of_bogies);
	};
	
}