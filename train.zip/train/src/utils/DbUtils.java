package utils;

import java.time.LocalDate;
import java.util.HashMap;

import com.core.Train;
import com.core.TrainType;

public class DbUtils {
	public static HashMap<String, Train> populateMap(){
		HashMap<String, Train>map=new HashMap<String, Train>();
		map.put("abc",new Train("abc", "kolhapuri", "dhdhx","dhdh", "pune", TrainType.EXPRESS, LocalDate.parse("2023-12-11"), "mumbai",15));
		map.put("xyz",new Train("xyz", "india", "dhdhx","dhdh", "chennai", TrainType.LOCAL, LocalDate.parse("2022-12-08"), "PUNE",12));
		map.put("pqr",new Train("pqr", "maharashtra", "dhdhx","sangli", "pune", TrainType.PASSENGER, LocalDate.parse("2023-10-11"), "KOLHAPUR",15));
		map.put("aaa",new Train("aaa", "kokan", "dhdhx","dhdh", "satara", TrainType.SUPERFAST, LocalDate.parse("2023-07-02"), "SANGLI",24));
		map.put("ccc",new Train("ccc", "goa", "dhdhx","dhdh", "pune", TrainType.EXPRESS, LocalDate.parse("2022-02-11"), "CHENNAI",19));
		
		return map;
	}
}
