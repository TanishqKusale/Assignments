package tester;

import java.util.Map;
import java.util.Scanner;
import static utils.DbUtils.populateMap;
import com.core.Train;
import static validation.Validation.addTrain;
import static validation.Validation.writeData;
public class TrainTest {
	public static void main(String[] args) {
		Map<String, Train> map = populateMap();
		try (Scanner sc = new Scanner(System.in)) {
			boolean exit = false;

			while (!exit) {
				System.out.println("1.toAdd 2.display 3.remove 4.display train name 5.sort 6.changedestination 7.exit");
				try {
					switch (sc.nextInt()) {
					case 1:
						System.out.println(
								" trainNo, train_name, departure_time, arrival_time, source, trainType ,train_added_date, destination, no_of_bogies");
						Train newTrain = addTrain(sc.next(), sc.next(), sc.next(), sc.next(), sc.next(), sc.next(),
								sc.next(), sc.next(), sc.nextInt());
						map.put(newTrain.getTrain_no(), newTrain);
						break;
					case 2:
						map.values().forEach(System.out::println);
						break;
					case 3:
						map.values().removeIf(t->t.getNo_of_bogies()<15);
						map.values().forEach(System.out::println);
						break;
					case 4:
						String destination = sc.next();
						map.values().stream().filter(t->t.getSource().equals(destination))
						.forEach(System.out::println);
						break;
					case 5:
						map.values().stream()
						.sorted((t1,t2)->((Integer)(t1.getNo_of_bogies())).compareTo(t2.getNo_of_bogies()))
						.forEach(System.out::println);
						break;
					case 6:
						map.values().stream().filter(t->t.getSource().equals("pune"))
						.forEach(t->t.setDestination("nashik"));
						break;

					case 7:
						writeData(map);
						System.exit(-1);
						break;
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

	}
}